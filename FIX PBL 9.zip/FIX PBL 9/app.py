from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from flask_mysqldb import MySQL
import bcrypt

app = Flask(__name__)
app.secret_key = "login flask"

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flaskdb'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)


@app.before_request
def add_nav_links():
    g.nav_links = get_nav_links()

@app.route('/guide')
def guide():
    return render_template('guide.html', nav_links=g.nav_links)


@app.route('/', methods=['GET', 'POST'])
def login_post():
    if request.method == 'GET':
        return render_template("login.html")  
    
    email = request.form['email']
    password = request.form['password'].encode('utf-8')
    curl = mysql.connection.cursor()
    curl.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = curl.fetchone()
    curl.close()

    if user is not None:
        if bcrypt.checkpw(password, user['password'].encode('utf-8')): 
            session['name'] = user['name']
            session['email'] = user['email']
            return redirect(url_for('home'))  
        else:
            flash("Gagal, Email dan password tidak cocok")
            return redirect(url_for('login_post'))  
    else:
        flash("Email not found")
        return render_template("login.html")  


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password'].encode('utf-8')

        if len(password) < 8 or len(set(password)) < 2:
            flash("Password must be at least 8 characters long with at least 2 unique characters.")
            return render_template('signup.html')
        
        hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO users (name,email,password) VALUES (%s,%s,%s)", (name, email, hashed_password))
            mysql.connection.commit()
        except Exception as e:
            flash(f"Error occurred: {str(e)}")
            return render_template('signup.html')
        finally:
            cur.close()

        return redirect(url_for('login_post'))

    return render_template('signup.html') 


def encrypt_vigenere(note, password):
    if note is None or note == "":
        raise ValueError("Note cannot be empty.")
    
    encrypted_note = []
    password = password.lower()  
    password_length = len(password)

    for i, char in enumerate(note):
        if char.isalpha():  
            shift = ord(password[i % password_length]) - ord('a')
            if char.islower():
                encrypted_note.append(chr((ord(char) - ord('a') + shift) % 26 + ord('a')))
            else:
                encrypted_note.append(chr((ord(char) - ord('A') + shift) % 26 + ord('A')))
        else:
            encrypted_note.append(char)  
    return ''.join(encrypted_note)

def decrypt_vigenere(encrypted_note, password):
    if encrypted_note is None or encrypted_note == "":
        raise ValueError("Encrypted note cannot be empty.")
    
    decrypted_note = []
    password = password.lower()  
    password_length = len(password)

    for i, char in enumerate(encrypted_note):
        if char.isalpha():  
            shift = ord(password[i % password_length]) - ord('a')
            if char.islower():
                decrypted_note.append(chr((ord(char) - ord('a') - shift) % 26 + ord('a')))
            else:
                decrypted_note.append(chr((ord(char) - ord('A') - shift) % 26 + ord('A')))
        else:
            decrypted_note.append(char)  

    return ''.join(decrypted_note)

def encrypt_math_formula(note):
    if note is None or note == "":
        raise ValueError("Note cannot be empty.")
    
    encrypted_note = []
    for char in note:
        if char.isalpha():
            numeric_value = ord(char)
            encrypted_value = (numeric_value * 2 + 5)  
            encrypted_note.append(str(encrypted_value))  
        else:
            encrypted_note.append(char)  
    return ' '.join(encrypted_note)  

def decrypt_math_formula(encrypted_note):
    if encrypted_note is None or encrypted_note == "":
        raise ValueError("Encrypted note cannot be empty.")
    
    decrypted_note = []
    for part in encrypted_note.split():  
        if part.isdigit():
            encrypted_value = int(part)
            numeric_value = (encrypted_value - 5) // 2  
            decrypted_note.append(chr(numeric_value))  
        else:
            decrypted_note.append(part)  
    return ''.join(decrypted_note)

def encrypt_morse_code(note):
    if note is None or note == "":
        raise ValueError("Note cannot be empty.")
    
    morse_mapping = {
        'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 
        'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 
        'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 
        'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 
        'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--', 
        'z': '--..', '0': '-----', '1': '.----', '2': '..---', 
        '3': '...--', '4': '....-', '5': '.....', '6': '-....', 
        '7': '--...', '8': '---..', '9': '----.', ' ': '/'
    }
    encrypted_note = ' '.join(morse_mapping.get(char, '') for char in note.lower())
    return encrypted_note

def decrypt_morse_code(morse_code):
    if morse_code is None or morse_code == "":
        raise ValueError("Morse code cannot be empty.")
    
    reverse_morse_mapping = {
        '.-': 'a', '-...': 'b', '-.-.': 'c', '-..': 'd', '.': 'e',
        '..-.': 'f', '--.': 'g', '....': 'h', '..': 'i', '.---': 'j',
        '-.-': 'k', '.-..': 'l', '--': 'm', '-.': 'n', '---': 'o',
        '.--.': 'p', '--.-': 'q', '.-.': 'r', '...': 's', '-': 't',
        '..-': 'u', '...-': 'v', '.--': 'w', '-..-': 'x', '-.--': 'y',
        '--..': 'z', '-----': '0', '.----': '1', '..---': '2',
        '...--': '3', '....-': '4', '.....': '5', '-....': '6',
        '--...': '7', '---..': '8', '----.': '9', '/': ' '  
    }
    words = morse_code.split(' ')  
    decrypted_note = []

    for code in words:
        if code in reverse_morse_mapping:
            decrypted_note.append(reverse_morse_mapping[code])
        else:
            decrypted_note.append('?')  

    return ''.join(decrypted_note)


notes = []

@app.route('/home')
def home():
    return render_template('home.html', nav_links=g.nav_links)

@app.route('/savenotes', methods=['GET', 'POST'])
def savenotes():
    if request.method == 'POST':
        title = request.form.get('title')
        note = request.form.get('note')
        password = request.form.get('password')
        hint = request.form.get('hint')
        encryption_type = request.form.get('encryption')

        if len(password) < 8 or len(set(password)) < 2:
            error = "Password must be at least 8 characters long with at least 2 unique characters."
            return render_template('save_notes.html', nav_links=g.nav_links, error=error)

        try:
            if encryption_type == 'text':
                encrypted_note = encrypt_vigenere(note, password)
            elif encryption_type == 'math':
                encrypted_note = encrypt_math_formula(note)
            elif encryption_type == 'morse':
                encrypted_note = encrypt_morse_code(note)
            else:
                error = "Invalid encryption type selected."
                return render_template('save_notes.html', nav_links=g.nav_links, error=error)
        except Exception as e:
            error = f"An error occurred during encryption: {str(e)}"
            return render_template('save_notes.html', nav_links=g.nav_links, error=error)

        notes.append({
            'title': title,
            'note': encrypted_note,
            'hint': hint,
            'password': password,
            'encryption': encryption_type
        })
        return redirect(url_for('all_notes'))

    return render_template('save_notes.html', nav_links=g.nav_links)

@app.route('/all_notes')
def all_notes():
    return render_template('all_notes.html', notes=notes, nav_links=g.nav_links)

@app.route('/note/<int:index>')
def note(index):
    if 0 <= index < len(notes):
        selected_note = notes[index]
        return render_template(
            'notes.html',
            index=index,
            note=selected_note,
            nav_links=g.nav_links
        )
    else:
        return "Note not found", 404

@app.route('/decrypt/<int:index>', methods=['POST'])
def decrypt(index):
    selected_note = notes[index]
    password = request.form.get('password')
    encryption_type = request.form.get('encryption_type')

    if not encryption_type:
        error = "Encryption type is missing. Please try again."
        return render_template(
            'notes.html',
            index=index,
            note=selected_note,
            error=error,
            nav_links=g.nav_links
        )

    
    if password != selected_note['password']:
        error = "Incorrect password. Please try again."
        return render_template(
            'notes.html',
            index=index,
            note=selected_note,
            error=error,
            nav_links=g.nav_links
        )

    
    encrypted_note = selected_note['note']
    decrypted_note = None

    try:
        if encryption_type == 'text':  
            decrypted_note = decrypt_vigenere(encrypted_note, password)
        elif encryption_type == 'morse':  
            if not all(char in ".-/ " for char in encrypted_note):
                error = "Invalid Morse Code format. Ensure it only contains '.', '-', '/', and spaces."
                return render_template(
                    'notes.html',
                    index=index,
                    note=selected_note,
                    error=error,
                    nav_links=g.nav_links
                )
            decrypted_note = decrypt_morse_code(encrypted_note)
        elif encryption_type == 'math':  
            decrypted_note = decrypt_math_formula(encrypted_note)
        else:
            error = "Unknown encryption type. Unable to decrypt."
            return render_template(
                'notes.html',
                index=index,
                note=selected_note,
                error=error,
                nav_links=g.nav_links
            )
    except Exception as e:
        error = f"An error occurred during decryption: {str(e)}"
        return render_template(
            'notes.html',
            index=index,
            note=selected_note,
            error=error,
            nav_links=g.nav_links
        )

    return render_template(
        'notes.html',
        index=index,
        note=selected_note,
        decrypted_note=decrypted_note,
        nav_links=g.nav_links
    )

def get_nav_links():
    return {
        'Home': url_for('home'),
        'Guide': url_for('guide'),
        'Save Notes': url_for('savenotes'),
        'All Notes': url_for('all_notes')
    }

if __name__ == '__main__':
    app.run(debug=True)
